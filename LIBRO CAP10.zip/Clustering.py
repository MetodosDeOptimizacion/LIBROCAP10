import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# Crear el dataset basado en la tabla de viviendas en Huancavelica
data = {
    "Distrito": ["Huancavelica", "Acobamba", "Angaraes", "Castrovirreyna", "Churcampa", "Huaytará", "Tayacaja"],
    "Total_Viviendas": [156819, 12000, 15000, 10000, 11000, 9000, 18000],
    "Viviendas_Ocupadas": [140024, 11000, 13500, 9500, 10500, 8500, 16500],
    "Viviendas_Desocupadas": [16795, 1000, 1500, 500, 500, 500, 1500],
    "Viviendas_Abandonadas": [13464, 700, 1000, 300, 350, 250, 1000]
}

# Convertir a DataFrame
df = pd.DataFrame(data)

# Normalizar los datos para evitar sesgos por escala
scaler = StandardScaler()
X = scaler.fit_transform(df.iloc[:, 1:])

# Aplicar K-Means
kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
df["Cluster"] = kmeans.fit_predict(X)

# Visualización de los clústeres
plt.figure(figsize=(10, 6))
plt.scatter(df["Total_Viviendas"], df["Viviendas_Ocupadas"], c=df["Cluster"], cmap='viridis', s=100, edgecolors='k')
plt.xlabel("Total de Viviendas")
plt.ylabel("Viviendas Ocupadas")
plt.title("Clustering de Distritos de Huancavelica basado en Viviendas")
plt.colorbar(label="Cluster")
plt.grid(True)
plt.show()

# Mostrar resultados en consola
print(df)
